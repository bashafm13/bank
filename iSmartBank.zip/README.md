# CiMoni SmartBank
Demo banking system structure.