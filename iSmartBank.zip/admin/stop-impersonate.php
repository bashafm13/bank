
<?php
session_start();
if (isset($_SESSION['impersonated_user'])) {
    $_SESSION['user_id'] = $_SESSION['impersonated_user'];
    unset($_SESSION['impersonated_user']);
    header("Location: ../admin/dashboard.php");
    exit;
}
?>
