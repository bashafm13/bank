
<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    die("Access denied.");
}
if (isset($_GET['user_id'])) {
    $_SESSION['impersonated_user'] = $_SESSION['user_id'];
    $_SESSION['user_id'] = $_GET['user_id'];
    header("Location: ../dashboard/home.php");
    exit;
}
?>
