
<?php
$host = 'localhost';
$user = 'your_db_user';
$pass = 'your_db_password';
$db   = 'your_db_name';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if (isset($_POST['email'])) {
    $email = trim($_POST['email']);
    $token = bin2hex(random_bytes(32));
    $stmt = $conn->prepare("UPDATE users SET reset_token=? WHERE email=?");
    $stmt->bind_param("ss", $token, $email);
    if ($stmt->execute()) {
        echo "Password reset link: https://yourbank.com/reset-password.php?token=$token";
    } else {
        echo "❌ Unable to process reset request.";
    }
}
?>
