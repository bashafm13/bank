
<?php
function sendResetLink($email, $token) {
    $subject = "Password Reset - SmartBank";
    $message = "Click the link to reset your password: https://yourbank.com/auth/reset-password.php?token=$token";
    $headers = "From: no-reply@smartbank.com";
    return mail($email, $subject, $message, $headers);
}
?>
