
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
// Add role-based redirects
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    // Admin specific access
}
?>
