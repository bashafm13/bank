
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - SmartBank</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <form method="POST" action="user-auth.php" class="bg-white p-6 rounded shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold mb-6 text-center">Login</h2>
        <input type="email" name="email" placeholder="Email" required class="w-full mb-4 px-3 py-2 border rounded" />
        <input type="password" name="password" placeholder="Password" required class="w-full mb-4 px-3 py-2 border rounded" />
        <button name="login" class="bg-blue-600 text-white w-full py-2 rounded hover:bg-blue-700">Login</button>
        <p class="text-sm text-center mt-4"><a href="password-reset.php" class="text-blue-500">Forgot Password?</a></p>
    </form>
</body>
</html>
