
<?php
$host = 'localhost';
$user = 'your_db_user';
$pass = 'your_db_password';
$db   = 'your_db_name';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if (isset($_GET['token']) && isset($_POST['password'])) {
    $token = $_GET['token'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE users SET password=?, reset_token=NULL WHERE reset_token=?");
    $stmt->bind_param("ss", $password, $token);
    if ($stmt->execute()) {
        echo "✅ Password updated successfully.";
    } else {
        echo "❌ Error updating password.";
    }
}
?>
