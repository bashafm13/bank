
<?php
$host = 'localhost';
$user = 'your_db_user';
$pass = 'your_db_password';
$db   = 'your_db_name';

// Connect to MySQL server
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("<h2 style='color:red;'>❌ Connection failed: " . $conn->connect_error . "</h2>");
}

// Create database if it doesn't exist
if (!$conn->query("CREATE DATABASE IF NOT EXISTS `$db`")) {
    die("<h2 style='color:red;'>❌ Database creation failed: " . $conn->error . "</h2>");
}

// Select the database
$conn->select_db($db);

// Import the schema file
$schemaFile = __DIR__ . '/schema.sql';
if (!file_exists($schemaFile)) {
    die("<h2 style='color:red;'>❌ Schema file not found!</h2>");
}

$schema = file_get_contents($schemaFile);
$queries = array_filter(array_map('trim', explode(';', $schema)));

$success = true;
foreach ($queries as $query) {
    if (!empty($query)) {
        if (!$conn->query($query)) {
            echo "<h4 style='color:red;'>❌ Error: " . $conn->error . "</h4><pre>$query</pre><hr>";
            $success = false;
        }
    }
}

if ($success) {
    echo "<h2 style='color:green;'>✅ All tables created successfully.</h2>";
} else {
    echo "<h2 style='color:orange;'>⚠️ Some tables may not have been created correctly. Please check the errors above.</h2>";
}

$conn->close();
?>
