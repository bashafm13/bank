
<?php
$host = 'localhost';
$user = 'your_db_user';
$pass = 'your_db_password';
$db   = 'your_db_name';

// Connect to MySQL server
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("<h2>❌ Connection failed: " . $conn->connect_error . "</h2>");
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS `$db`";
if (!$conn->query($sql)) {
    die("<h2>❌ Database creation failed: " . $conn->error . "</h2>");
}

// Select the database
$conn->select_db($db);

// Import the schema
$schema = file_get_contents(__DIR__ . '/schema.sql');
if ($conn->multi_query($schema)) {
    do {
        // Flush multi_query results
    } while ($conn->next_result());
    echo "<h2>✅ Database and tables created successfully.</h2>";
} else {
    echo "<h2>❌ Error importing schema: " . $conn->error . "</h2>";
}

$conn->close();
?>
