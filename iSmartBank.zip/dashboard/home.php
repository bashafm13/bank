
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'user';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">
    <div class="max-w-4xl mx-auto mt-10 p-6 bg-white shadow rounded">
        <h1 class="text-3xl font-bold">Welcome back, User #<?= $user_id ?>!</h1>
        <p class="mt-2">Your role is <strong><?= ucfirst($role) ?></strong>.</p>
        <?php if ($role === 'admin'): ?>
            <p class="mt-4 bg-yellow-100 p-3 rounded">👑 You have admin privileges. <a href="../admin/dashboard.php" class="text-blue-500">Go to Admin Panel</a></p>
        <?php endif; ?>
    </div>
</body>
</html>
