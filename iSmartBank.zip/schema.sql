
-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    password VARCHAR(255),
    role ENUM('user', 'admin') DEFAULT 'user',
    kyc_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Accounts table
CREATE TABLE accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    account_number VARCHAR(20) UNIQUE,
    currency VARCHAR(10),
    balance DECIMAL(20,2) DEFAULT 0,
    status ENUM('active', 'frozen') DEFAULT 'active',
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Transactions table
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT,
    type ENUM('credit', 'debit'),
    amount DECIMAL(20,2),
    description TEXT,
    status ENUM('pending', 'completed', 'failed'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(account_id) REFERENCES accounts(id)
);

-- Beneficiaries
CREATE TABLE beneficiaries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(100),
    account_number VARCHAR(20),
    bank_name VARCHAR(100),
    currency VARCHAR(10),
    FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Scheduled Transfers
CREATE TABLE scheduled_transfers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    beneficiary_id INT,
    amount DECIMAL(20,2),
    schedule VARCHAR(50),
    next_run TIMESTAMP,
    status ENUM('active', 'paused'),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(beneficiary_id) REFERENCES beneficiaries(id)
);

-- Support Tickets
CREATE TABLE support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    subject VARCHAR(150),
    message TEXT,
    status ENUM('open', 'closed', 'pending') DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
